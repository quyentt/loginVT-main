/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'image2', 'hu', {
	alt: 'Alternatív szöveg',
	btnUpload: 'Küldés a szerverre',
	captioned: 'Feliratozott kép',
	captionPlaceholder: 'Képfelirat',
	infoTab: 'Alaptulajdonságok',
	lockRatio: 'Arány megtartása',
	menu: 'Kép tulajdonságai',
	pathName: 'kép',
	pathNameCaption: 'felirat',
	resetSize: 'Eredeti méret',
	resizer: 'Kattintson és húzza az átméretezéshez',
	title: 'Kép tulajdonságai',
	uploadTab: 'Feltöltés',
	urlMissing: 'Hiányzik a kép URL-je',
	altMissing: 'Az alternatív szöveg hiányzik.'
} );
