/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'image2', 'ug', {
	alt: 'تېكىست ئالماشتۇر',
	btnUpload: 'مۇلازىمېتىرغا يۈكلە',
	captioned: 'ماۋزۇلۇق سۈرەت',
	captionPlaceholder: 'ماۋزۇ',
	infoTab: 'سۈرەت',
	lockRatio: 'نىسبەتنى قۇلۇپلا',
	menu: 'سۈرەت خاسلىقى',
	pathName: 'رەسىم',
	pathNameCaption: 'ماۋزۇ',
	resetSize: 'ئەسلى چوڭلۇق',
	resizer: 'چېكىپ تۇرۇپ سۆرەپ چوڭ كىچىكلىكىنى تەڭشىگىلى بولىدۇ',
	title: 'سۈرەت خاسلىقى',
	uploadTab: 'يۈكلە',
	urlMissing: 'سۈرەتنىڭ ئەسلى ھۆججەت ئادرېسى كەم',
	altMissing: 'باشقا تېكىست كەمچىل'
} );
