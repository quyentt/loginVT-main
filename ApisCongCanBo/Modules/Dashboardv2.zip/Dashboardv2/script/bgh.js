// BGH Dashboard JavaScript

// KPI Data với tính toán xu hướng và dữ liệu mẫu phong phú
const kpiData = [
    {
        id: 'kpi1',
        icon: 'users',
        label: 'Tổng số sinh viên đang học',
        category: 'Quy mô sinh viên',
        value: '33,000',
        previousValue: 31800,
        currentValue: 33000,
        trend: 'up',
        trendValue: '+3.8%',
        trendNumber: 1200,
        subtext: 'so với cùng kỳ năm trước',
        color: 'blue',
        isGoodKPI: true,
        lastUpdated: 'Tháng 12/2024',
        tooltip: 'Dữ liệu cập nhật đến tháng 12/2024'
    },
    {
        id: 'kpi2',
        icon: 'graduation-cap',
        label: 'Sinh viên nhập học mới',
        category: 'Tuyển sinh',
        value: '12,800',
        target: 15000,
        achievement: 85.3,
        previousValue: 11500,
        currentValue: 12800,
        trend: 'up',
        trendValue: '+11.3%',
        trendNumber: 1300,
        subtext: '85.3% chỉ tiêu (15,000 SV)',
        color: 'green',
        isGoodKPI: true,
        lastUpdated: 'Năm học 2024-2025',
        tooltip: 'Dữ liệu cập nhật đến năm học 2024-2025'
    },
    {
        id: 'kpi3',
        icon: 'award',
        label: 'Tỷ lệ TN đúng hạn',
        category: 'Chỉ số vàng',
        value: '68.5%',
        target: 75,
        previousValue: 65.2,
        currentValue: 68.5,
        trend: 'up',
        trendValue: '+5.1%',
        trendNumber: 3.3,
        subtext: 'Mục tiêu 75% (còn thiếu 6.5%)',
        color: 'orange',
        isGoodKPI: true,
        lastUpdated: 'Năm học 2024',
        tooltip: 'Dữ liệu cập nhật đến năm học 2024'
    },
    {
        id: 'kpi4',
        icon: 'alert-triangle',
        label: 'Tỷ lệ SV bị cảnh báo học vụ',
        category: 'Rủi ro',
        value: '2.1%',
        previousValue: 2.8,
        currentValue: 2.1,
        trend: 'down',
        trendValue: '-25.0%',
        trendNumber: -0.7,
        subtext: '693 sinh viên (giảm 231 SV)',
        color: 'red',
        isGoodKPI: false, // KPI xấu - giảm là tốt
        lastUpdated: 'Học kỳ 1/2024-2025',
        tooltip: 'Dữ liệu cập nhật đến học kỳ 1/2024-2025'
    }
];

// Stats data sử dụng kpiData
const statsData = kpiData;

// Risk data với dữ liệu mẫu chi tiết hơn
const riskData = [
    {
        id: 'RR-001',
        name: 'Tỷ lệ GPA TB thấp dưới mức 2.0',
        level: 'Cao',
        status: 'Đang theo dõi',
        color: 'red',
        details: '450 SV có GPA < 2.0, cần can thiệp ngay',
        affectedStudents: 450,
        department: 'Toàn trường'
    },
    {
        id: 'RR-002',
        name: 'Tỷ lệ TN chậm tăng cao',
        level: 'Trung bình',
        status: 'Đang xử lý',
        color: 'yellow',
        details: '31.5% SV TN chậm, cần cải thiện CTĐT',
        affectedStudents: 2850,
        department: 'Khoa Kỹ thuật, Khoa CNTT'
    },
    {
        id: 'RR-003',
        name: 'Nợ học phí tăng đột biến',
        level: 'Trung bình',
        status: 'Theo dõi',
        color: 'yellow',
        details: '1,200 SV nợ học phí > 2 kỳ',
        affectedStudents: 1200,
        department: 'Toàn trường'
    },
    {
        id: 'RR-004',
        name: 'Thiếu giảng viên có trình độ TS',
        level: 'Thấp',
        status: 'Kế hoạch dài hạn',
        color: 'green',
        details: 'Tỷ lệ GV có TS chỉ đạt 35.2%',
        affectedStudents: 0,
        department: 'Khoa Ngoại ngữ, Khoa Kinh tế'
    }
];

// Faculty Risk Score System - Hệ thống tính điểm rủi ro theo khoa
const facultyRiskData = [
    {
        name: 'Khoa Công nghệ thông tin',
        riskScore: 85.2,
        previousScore: 72.8,
        trend: 'increase_high', // >=10 điểm
        trendValue: '+12.4',
        level: 'Cao',
        color: 'red',
        mainCause: 'GPA TB ↓, Tỷ lệ trượt ↑',
        details: {
            gpaAvg: 2.15, // A1 - Điểm 60
            failRate: 28.5, // A2 - Điểm 70
            lateGrading: 18.2, // B1 - Điểm 100
            scheduleViolation: 12.5, // B2 - Điểm 100
            warningRate: 22.3, // C1 - Điểm 100
            dropoutRate: 8.1, // C2 - Điểm 100
            enrollmentDecline: 6.2 // D1 - Điểm 70
        },
        riskFactors: [
            'Chất lượng học tập chưa đạt yêu cầu',
            'Tỷ lệ trượt học phần rất cao',
            'Chậm nhập điểm ảnh hưởng kế hoạch học tập',
            'SV cảnh báo học vụ rất nghiêm trọng'
        ]
    },
    {
        name: 'Khoa Cơ khí',
        riskScore: 76.8,
        previousScore: 69.2,
        trend: 'increase', // 5-10 điểm
        trendValue: '+7.6',
        level: 'Trung bình',
        color: 'yellow',
        mainCause: 'SV thôi học cao',
        details: {
            gpaAvg: 2.68,
            failRate: 22.1,
            lateGrading: 8.5,
            scheduleViolation: 6.2,
            warningRate: 18.7,
            dropoutRate: 7.8,
            enrollmentDecline: 4.1
        },
        riskFactors: [
            'SV thôi học rất cao',
            'Nhiều học phần có tỷ lệ không đạt cao',
            'SV cảnh báo học vụ cao'
        ]
    },
    {
        name: 'Khoa Kinh tế',
        riskScore: 68.4,
        previousScore: 71.9,
        trend: 'decrease', // <5 điểm giảm
        trendValue: '-3.5',
        level: 'Trung bình',
        color: 'yellow',
        mainCause: 'Nhập điểm trễ',
        details: {
            gpaAvg: 2.95,
            failRate: 15.2,
            lateGrading: 16.8,
            scheduleViolation: 8.9,
            warningRate: 12.4,
            dropoutRate: 4.2,
            enrollmentDecline: 2.8
        },
        riskFactors: [
            'Nhập điểm trễ',
            'Cảnh báo nhập điểm',
            'SV cảnh báo học vụ cao'
        ]
    },
    {
        name: 'Khoa Ngoại ngữ',
        riskScore: 58.7,
        previousScore: 55.3,
        trend: 'stable', // <5 điểm
        trendValue: '+3.4',
        level: 'Trung bình',
        color: 'yellow',
        mainCause: 'Vi phạm tiến độ đào tạo',
        details: {
            gpaAvg: 3.05,
            failRate: 12.8,
            lateGrading: 7.2,
            scheduleViolation: 11.5,
            warningRate: 8.9,
            dropoutRate: 3.1,
            enrollmentDecline: 1.8
        },
        riskFactors: [
            'Tiến độ đào tạo không đảm bảo',
            'Cần theo dõi vi phạm tiến độ'
        ]
    },
    {
        name: 'Khoa Y tế',
        riskScore: 52.1,
        previousScore: 48.6,
        trend: 'stable',
        trendValue: '+3.5',
        level: 'Trung bình',
        color: 'yellow',
        mainCause: 'Tỷ lệ trượt học phần cao',
        details: {
            gpaAvg: 3.18,
            failRate: 18.5,
            lateGrading: 4.2,
            scheduleViolation: 3.8,
            warningRate: 6.7,
            dropoutRate: 2.8,
            enrollmentDecline: 0.9
        },
        riskFactors: [
            'Tỷ lệ trượt học phần cao',
            'Cần rà soát công tác giảng dạy'
        ]
    },
    {
        name: 'Khoa Kỹ thuật',
        riskScore: 45.3,
        previousScore: 42.1,
        trend: 'stable',
        trendValue: '+3.2',
        level: 'Thấp',
        color: 'green',
        mainCause: 'Ổn định chung',
        details: {
            gpaAvg: 3.02,
            failRate: 14.2,
            lateGrading: 3.8,
            scheduleViolation: 4.1,
            warningRate: 7.2,
            dropoutRate: 2.9,
            enrollmentDecline: 1.2
        },
        riskFactors: [
            'Bắt đầu cần theo dõi tỷ lệ trượt',
            'Tình hình chung ổn định'
        ]
    }
];

// Risk Score Calculation Functions
function calculateRiskScore(faculty) {
    const weights = {
        gpa: 0.25,      // A1 - 25%
        failRate: 0.25, // A2 - 25%
        lateGrading: 0.10, // B1 - 10%
        scheduleViolation: 0.10, // B2 - 10%
        warningRate: 0.10, // C1 - 10%
        dropoutRate: 0.10, // C2 - 10%
        enrollmentDecline: 0.10 // D1 - 10%
    };
    
    // Normalize each metric to 0-100 scale
    const normalized = {
        gpa: normalizeGPA(faculty.details.gpaAvg),
        failRate: normalizeFailRate(faculty.details.failRate),
        lateGrading: normalizeLateGrading(faculty.details.lateGrading),
        scheduleViolation: normalizeScheduleViolation(faculty.details.scheduleViolation),
        warningRate: normalizeWarningRate(faculty.details.warningRate),
        dropoutRate: normalizeDropoutRate(faculty.details.dropoutRate),
        enrollmentDecline: normalizeEnrollmentDecline(faculty.details.enrollmentDecline)
    };
    
    // Calculate weighted score
    return Object.keys(weights).reduce((score, key) => {
        return score + (normalized[key] * weights[key] * 100);
    }, 0);
}

// Normalization functions based on the specification
function normalizeGPA(gpa) {
    if (gpa >= 3.2) return 0;      // Tốt
    if (gpa >= 2.5) return 0.3;    // Chấp nhận
    if (gpa >= 2.0) return 0.6;    // Rủi ro
    return 1.0;                    // Rủi ro cao
}

function normalizeFailRate(rate) {
    if (rate < 10) return 0;       // Bình thường
    if (rate < 20) return 0.4;     // Cảnh báo
    if (rate < 30) return 0.7;     // Rủi ro
    return 1.0;                    // Rủi ro cao
}

function normalizeLateGrading(rate) {
    if (rate < 5) return 0;        // Tuân thủ tốt
    if (rate < 10) return 0.3;     // Cảnh báo
    if (rate < 15) return 0.6;     // Nhập điểm trễ
    return 1.0;                    // Nhập điểm rất trễ
}

function normalizeScheduleViolation(rate) {
    if (rate < 5) return 0;        // Tuân thủ tốt
    if (rate < 10) return 0.5;     // Cần theo dõi
    return 1.0;                    // Rủi ro cao
}

function normalizeWarningRate(rate) {
    if (rate < 10) return 0;       // Ổn định
    if (rate < 15) return 0.3;     // Bắt đầu cần theo dõi
    if (rate < 20) return 0.6;     // Rủi ro rõ
    return 1.0;                    // Rủi ro cao
}

function normalizeDropoutRate(rate) {
    if (rate < 3) return 0;        // Ổn định
    if (rate < 5) return 0.4;      // Bắt đầu cần theo dõi
    if (rate < 7) return 0.7;      // Rủi ro rõ
    return 1.0;                    // Rủi ro cao
}

function normalizeEnrollmentDecline(rate) {
    if (rate <= 0) return 0;       // Quy mô ổn định/tăng
    if (rate < 3) return 0.3;      // Biến động nhẹ
    if (rate < 5) return 0.6;      // Rủi ro rõ
    if (rate < 8) return 0.8;      // Rủi ro cao
    return 1.0;                    // Rủi ro rất cao
}

function getRiskLevel(score) {
    if (score >= 80) return { level: 'Cao', color: 'red' };
    if (score >= 50) return { level: 'Trung bình', color: 'yellow' };
    return { level: 'Thấp', color: 'green' };
}

function getTrendIcon(trend) {
    switch(trend) {
        case 'increase_high': return '↑↑';
        case 'increase': return '↑';
        case 'decrease': return '↓';
        default: return '→';
    }
}

function getTrendColor(trend) {
    switch(trend) {
        case 'increase_high': return 'text-red-600';
        case 'increase': return 'text-orange-600';
        case 'decrease': return 'text-green-600';
        default: return 'text-gray-600';
    }
}

// Faculty data với thông tin chi tiết
const facultyData = [
    { name: 'Khoa CNTT', students: 8500, gpa: 3.25, programs: 6, passRate: 92.5 },
    { name: 'Khoa Kinh tế', students: 7200, gpa: 3.08, programs: 5, passRate: 88.2 },
    { name: 'Khoa Ngoại ngữ', students: 4800, gpa: 3.15, programs: 4, passRate: 90.1 },
    { name: 'Khoa Kỹ thuật', students: 6200, gpa: 3.02, programs: 7, passRate: 85.8 },
    { name: 'Khoa Y tế', students: 6300, gpa: 3.18, programs: 3, passRate: 89.6 }
];

// Chart data với dữ liệu thực tế hơn
const gpaChartData = {
    labels: facultyData.map(f => f.name),
    datasets: [
        {
            label: 'GPA TB',
            data: facultyData.map(f => f.gpa),
            backgroundColor: 'rgba(59, 130, 246, 0.8)',
            borderColor: 'rgba(59, 130, 246, 1)',
            borderWidth: 2,
            yAxisID: 'y',
        },
        {
            label: 'Tỷ lệ đỗ (%)',
            data: facultyData.map(f => f.passRate),
            type: 'line',
            borderColor: 'rgba(239, 68, 68, 1)',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            borderWidth: 3,
            tension: 0.4,
            yAxisID: 'y1',
        }
    ]
};

const studentFlowChartData = {
    labels: ['2020', '2021', '2022', '2023', '2024', '2025 (dự kiến)'],
    datasets: [
        {
            label: 'SV nhập mới',
            data: [9800, 10500, 11200, 11800, 12800, 13500],
            borderColor: 'rgba(16, 185, 129, 1)',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            borderWidth: 3,
            tension: 0.4,
            fill: true,
        },
        {
            label: 'SV đang học',
            data: [28500, 29800, 31200, 32100, 33000, 34200],
            borderColor: 'rgba(59, 130, 246, 1)',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            borderWidth: 3,
            tension: 0.4,
            fill: true,
        },
        {
            label: 'SV tốt nghiệp',
            data: [8200, 8800, 9100, 9400, 9800, 10500],
            borderColor: 'rgba(245, 158, 11, 1)',
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            borderWidth: 3,
            tension: 0.4,
            fill: true,
        }
    ]
};

const tuitionChartData = {
    labels: ['Tháng 8', 'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'],
    datasets: [
        {
            label: 'Đã thu (tỷ)',
            data: [45, 75, 95, 112, 125],
            backgroundColor: 'rgba(59, 130, 246, 0.8)',
            borderColor: 'rgba(59, 130, 246, 1)',
            borderWidth: 2,
            yAxisID: 'y',
        },
        {
            label: 'Mục tiêu (tỷ)',
            data: [50, 80, 100, 115, 132],
            backgroundColor: 'rgba(16, 185, 129, 0.8)',
            borderColor: 'rgba(16, 185, 129, 1)',
            borderWidth: 2,
            yAxisID: 'y',
        },
        {
            label: 'Tỷ lệ thu (%)',
            data: [90, 94, 95, 97, 95],
            type: 'line',
            borderColor: 'rgba(239, 68, 68, 1)',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            borderWidth: 3,
            tension: 0.4,
            yAxisID: 'y1',
        }
    ]
};

// Helper functions
function getColorClasses(color) {
    const colors = {
        blue: { bg: 'from-blue-50 to-blue-100', border: 'border-blue-200', icon: 'bg-blue-500' },
        green: { bg: 'from-green-50 to-green-100', border: 'border-green-200', icon: 'bg-green-500' },
        red: { bg: 'from-red-50 to-red-100', border: 'border-red-200', icon: 'bg-red-500' },
        orange: { bg: 'from-orange-50 to-orange-100', border: 'border-orange-200', icon: 'bg-orange-500' }
    };
    return colors[color] || colors.blue;
}

function getTrendIcon(trend, isGoodKPI) {
    if (trend === 'up') {
        return isGoodKPI ? 'trending-up' : 'trending-up';
    } else if (trend === 'down') {
        return isGoodKPI ? 'trending-down' : 'trending-down';
    } else {
        return 'minus';
    }
}

function getTrendColor(trend, isGoodKPI) {
    if (trend === 'up') {
        return isGoodKPI ? 'text-green-600 bg-green-100' : 'text-red-600 bg-red-100';
    } else if (trend === 'down') {
        return isGoodKPI ? 'text-red-600 bg-red-100' : 'text-green-600 bg-green-100';
    } else {
        return 'text-gray-600 bg-gray-100';
    }
}

// Render functions
function renderStatsCards() {
    const container = document.getElementById('statsCards');
    container.innerHTML = statsData.map(stat => {
        const colors = getColorClasses(stat.color);
        const trendIcon = getTrendIcon(stat.trend, stat.isGoodKPI);
        const trendColor = getTrendColor(stat.trend, stat.isGoodKPI);
        
        return `
            <div class="bg-gradient-to-br ${colors.bg} rounded-2xl shadow-lg p-6 border-2 ${colors.border} hover:shadow-xl transition-all transform hover:-translate-y-1 cursor-pointer" 
                 data-tooltip="${stat.tooltip}" 
                 onmouseover="showTooltip(event, '${stat.tooltip}')" 
                 onmouseout="hideTooltip()">
                <div class="flex items-start justify-between mb-4">
                    <div class="p-3 rounded-xl ${colors.icon} text-white shadow-md">
                        <i data-lucide="${stat.icon}" class="w-7 h-7"></i>
                    </div>
                    <div class="flex items-center ${trendColor} px-3 py-1 rounded-full">
                        <i data-lucide="${trendIcon}" class="w-4 h-4 mr-1"></i>
                        <span class="text-xs font-bold">${stat.trendValue}</span>
                    </div>
                </div>
                <div class="mb-2">
                    <span class="text-xs font-medium text-gray-500 uppercase tracking-wide">${stat.category}</span>
                </div>
                <h3 class="text-gray-700 text-sm font-semibold mb-3 leading-tight">${stat.label}</h3>
                <p class="text-4xl font-bold text-gray-900 mb-2">${stat.value}</p>
                <p class="text-sm text-gray-600">${stat.subtext}</p>
                ${stat.target ? `<div class="mt-2 text-xs text-gray-500">Mục tiêu: ${stat.target}${stat.achievement ? ` (${stat.achievement}%)` : ''}</div>` : ''}
            </div>
        `;
    }).join('');
    lucide.createIcons();
}

function renderRiskList() {
    const container = document.getElementById('riskList');
    
    // Sort faculties by risk score (highest first) and take top 6
    const topRiskFaculties = facultyRiskData
        .sort((a, b) => b.riskScore - a.riskScore)
        .slice(0, 6);
    
    container.innerHTML = `
        <div class="mb-4">
            <h3 class="text-lg font-bold text-gray-800 mb-2">TOP Khoa có Risk Score cao nhất</h3>
            <p class="text-sm text-gray-600 mb-4">Danh sách các khoa cần tập trung chỉ đạo (dữ liệu cập nhật theo học kỳ)</p>
        </div>
        <div class="space-y-3">
            ${topRiskFaculties.map((faculty, index) => {
                const levelColors = {
                    'Cao': 'bg-red-100 border-red-300 text-red-800',
                    'Trung bình': 'bg-yellow-100 border-yellow-300 text-yellow-800',
                    'Thấp': 'bg-green-100 border-green-300 text-green-800'
                };
                
                const trendColor = getTrendColor(faculty.trend);
                const trendIcon = getTrendIcon(faculty.trend);
                
                return `
                    <div class="p-4 rounded-xl border-2 ${levelColors[faculty.level]} hover:shadow-lg transition-all cursor-pointer"
                         onmouseover="showRiskTooltip(event, ${index})" 
                         onmouseout="hideTooltip()">
                        <div class="flex items-center justify-between mb-2">
                            <div class="flex items-center space-x-3">
                                <span class="text-sm font-bold text-gray-600">#${index + 1}</span>
                                <h4 class="font-bold text-gray-900">${faculty.name}</h4>
                            </div>
                            <div class="flex items-center space-x-2">
                                <span class="text-2xl font-bold">${faculty.riskScore.toFixed(1)}</span>
                                <span class="text-xs ${trendColor} font-bold">${trendIcon} ${faculty.trendValue}</span>
                            </div>
                        </div>
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm font-semibold text-gray-700">Nguyên nhân chính:</p>
                                <p class="text-sm text-gray-600">${faculty.mainCause}</p>
                            </div>
                            <div class="text-right">
                                <span class="inline-block px-3 py-1 text-xs font-bold rounded-full ${levelColors[faculty.level]}">
                                    ${faculty.level}
                                </span>
                            </div>
                        </div>
                    </div>
                `;
            }).join('')}
        </div>
        
        <!-- Risk Score Legend -->
        <div class="mt-6 p-4 bg-gray-50 rounded-xl border-2 border-gray-200">
            <h4 class="font-bold text-gray-800 mb-3">Thang điểm Risk Score</h4>
            <div class="grid grid-cols-3 gap-3 text-xs">
                <div class="flex items-center space-x-2">
                    <div class="w-4 h-4 bg-red-500 rounded"></div>
                    <span>Cao: ≥80 điểm</span>
                </div>
                <div class="flex items-center space-x-2">
                    <div class="w-4 h-4 bg-yellow-500 rounded"></div>
                    <span>TB: 50-79 điểm</span>
                </div>
                <div class="flex items-center space-x-2">
                    <div class="w-4 h-4 bg-green-500 rounded"></div>
                    <span>Thấp: <50 điểm</span>
                </div>
            </div>
            <div class="mt-3 text-xs text-gray-600">
                <p><strong>Xu hướng:</strong> ↑↑ Tăng mạnh (≥10), ↑ Tăng (5-10), → Ổn định (<5), ↓ Giảm</p>
            </div>
        </div>
    `;
}

// Risk tooltip function
function showRiskTooltip(event, facultyIndex) {
    const faculty = facultyRiskData
        .sort((a, b) => b.riskScore - a.riskScore)
        .slice(0, 6)[facultyIndex];
    
    const tooltip = document.getElementById('riskTooltip') || createRiskTooltip();
    
    const riskFactorsList = faculty.riskFactors.map(factor => `• ${factor}`).join('<br>');
    
    tooltip.innerHTML = `
        <div class="max-w-sm">
            <h4 class="font-bold text-white mb-2">${faculty.name}</h4>
            <div class="text-sm text-gray-200 space-y-1">
                <p><strong>Risk Score:</strong> ${faculty.riskScore.toFixed(1)} (${faculty.level})</p>
                <p><strong>Xu hướng:</strong> ${faculty.trendValue} so với kỳ trước</p>
                <hr class="border-gray-600 my-2">
                <p><strong>Chi tiết nguyên nhân:</strong></p>
                <div class="text-xs mt-1">${riskFactorsList}</div>
                <hr class="border-gray-600 my-2">
                <div class="text-xs">
                    <p><strong>Chỉ số chi tiết:</strong></p>
                    <p>• GPA TB: ${faculty.details.gpaAvg}</p>
                    <p>• Tỷ lệ trượt: ${faculty.details.failRate}%</p>
                    <p>• Nhập điểm trễ: ${faculty.details.lateGrading}%</p>
                    <p>• SV cảnh báo: ${faculty.details.warningRate}%</p>
                    <p>• SV thôi học: ${faculty.details.dropoutRate}%</p>
                </div>
            </div>
        </div>
    `;
    
    tooltip.style.display = 'block';
    tooltip.style.left = Math.min(event.pageX + 10, window.innerWidth - 300) + 'px';
    tooltip.style.top = Math.max(event.pageY - 100, 10) + 'px';
}

function createRiskTooltip() {
    const tooltip = document.createElement('div');
    tooltip.id = 'riskTooltip';
    tooltip.className = 'absolute bg-gray-900 text-white text-xs p-4 rounded-lg shadow-xl z-50 pointer-events-none border border-gray-700';
    tooltip.style.display = 'none';
    tooltip.style.maxWidth = '350px';
    document.body.appendChild(tooltip);
    return tooltip;
}

function renderFacultyList() {
    const container = document.getElementById('facultyList');
    container.innerHTML = facultyData.map(faculty => `
        <div class="p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border-2 border-blue-200 hover:shadow-md transition-all cursor-pointer">
            <p class="text-sm font-semibold text-blue-900">${faculty.name}</p>
            <div class="text-xs text-blue-700 mt-1">
                <span>${faculty.students.toLocaleString()} SV</span> • 
                <span>GPA: ${faculty.gpa}</span>
            </div>
        </div>
    `).join('');
}

function renderQuickStats() {
    const container = document.getElementById('quickStats');
    const totalStudents = facultyData.reduce((sum, f) => sum + f.students, 0);
    const avgGPA = (facultyData.reduce((sum, f) => sum + f.gpa, 0) / facultyData.length).toFixed(2);
    const totalPrograms = facultyData.reduce((sum, f) => sum + f.programs, 0);
    
    container.innerHTML = `
        <div class="flex justify-between">
            <span class="text-gray-600">Tổng số khoa:</span>
            <span class="font-bold text-gray-800">${facultyData.length}</span>
        </div>
        <div class="flex justify-between">
            <span class="text-gray-600">Tổng số ngành:</span>
            <span class="font-bold text-gray-800">${totalPrograms}</span>
        </div>
        <div class="flex justify-between">
            <span class="text-gray-600">GPA TB toàn trường:</span>
            <span class="font-bold text-blue-600">${avgGPA}</span>
        </div>
        <div class="flex justify-between">
            <span class="text-gray-600">Tỷ lệ có việc làm:</span>
            <span class="font-bold text-green-600">92.8%</span>
        </div>
        <div class="flex justify-between">
            <span class="text-gray-600">Tổng SV đang học:</span>
            <span class="font-bold text-blue-600">${totalStudents.toLocaleString()}</span>
        </div>
    `;
}

// Tooltip functions
function showTooltip(event, text) {
    const tooltip = document.getElementById('tooltip') || createTooltip();
    tooltip.textContent = text;
    tooltip.style.display = 'block';
    tooltip.style.left = event.pageX + 10 + 'px';
    tooltip.style.top = event.pageY - 30 + 'px';
}

function hideTooltip() {
    const tooltip = document.getElementById('tooltip');
    const riskTooltip = document.getElementById('riskTooltip');
    
    if (tooltip) {
        tooltip.style.display = 'none';
    }
    if (riskTooltip) {
        riskTooltip.style.display = 'none';
    }
}

function createTooltip() {
    const tooltip = document.createElement('div');
    tooltip.id = 'tooltip';
    tooltip.className = 'absolute bg-gray-800 text-white text-xs px-3 py-2 rounded-lg shadow-lg z-50 pointer-events-none';
    tooltip.style.display = 'none';
    document.body.appendChild(tooltip);
    return tooltip;
}

// Chart options
const chartOptions = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
        legend: {
            display: true,
            position: 'top',
            labels: {
                font: { size: 12, weight: 'bold' },
                padding: 15
            }
        },
        tooltip: {
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            titleColor: '#1f2937',
            bodyColor: '#4b5563',
            borderColor: '#e5e7eb',
            borderWidth: 2,
            padding: 12,
            cornerRadius: 8
        }
    },
    scales: {
        y: {
            beginAtZero: true,
            grid: { color: 'rgba(0, 0, 0, 0.05)' }
        },
        y1: {
            beginAtZero: true,
            position: 'right',
            grid: { drawOnChartArea: false }
        }
    }
};

// GPA Chart options với tooltip tùy chỉnh
const gpaChartOptions = {
    ...chartOptions,
    plugins: {
        ...chartOptions.plugins,
        tooltip: {
            ...chartOptions.plugins.tooltip,
            callbacks: {
                afterBody: function(context) {
                    const dataIndex = context[0].dataIndex;
                    const faculty = facultyData[dataIndex];
                    const gpa = faculty.gpa;
                    const passRate = faculty.passRate;
                    
                    let analysis = '';
                    if (gpa > 2.5 && passRate > 90) {
                        analysis = '✅ GPA TB cao, Tỷ lệ đỗ cao, chất lượng đào tạo tốt';
                    } else if (gpa <= 2.5 && passRate > 90) {
                        analysis = '⚠️ GPA TB thấp, Tỷ lệ đỗ cao, chất lượng đào tạo chưa cao';
                    } else if (gpa > 2.5 && passRate <= 90) {
                        analysis = '📊 GPA TB cao, tỷ lệ đỗ thấp, đào tạo có sự phân hóa mạnh';
                    } else {
                        analysis = '❌ Chất lượng đào tạo kém';
                    }
                    
                    return [
                        '',
                        `📈 Phân tích: ${analysis}`,
                        `👥 Số sinh viên: ${faculty.students.toLocaleString()}`,
                        `📚 Số ngành: ${faculty.programs}`
                    ];
                }
            }
        }
    }
};

// Student Flow Chart options với tooltip phân tích kịch bản
const studentFlowChartOptions = {
    ...chartOptions,
    plugins: {
        ...chartOptions.plugins,
        tooltip: {
            ...chartOptions.plugins.tooltip,
            callbacks: {
                afterBody: function(context) {
                    const dataIndex = context[0].dataIndex;
                    const year = studentFlowChartData.labels[dataIndex];
                    
                    // Lấy dữ liệu năm hiện tại và năm trước
                    const currentNew = studentFlowChartData.datasets[0].data[dataIndex];
                    const currentStudying = studentFlowChartData.datasets[1].data[dataIndex];
                    const currentGraduated = studentFlowChartData.datasets[2].data[dataIndex];
                    
                    let scenario = '';
                    let analysis = '';
                    
                    if (dataIndex > 0) {
                        const prevStudying = studentFlowChartData.datasets[1].data[dataIndex - 1];
                        const studyingTrend = currentStudying >= prevStudying ? 'tăng' : 'giảm';
                        
                        if (currentNew >= currentGraduated && studyingTrend === 'tăng') {
                            scenario = '🟢 Kịch bản 1: Phát triển ổn định';
                            analysis = 'SV nhập học ≥ SV tốt nghiệp, quy mô đào tạo bền vững';
                        } else if (currentGraduated > currentNew && studyingTrend === 'giảm') {
                            scenario = '🟡 Kịch bản 2: Cảnh báo tuyển sinh';
                            analysis = 'SV tốt nghiệp > SV nhập học, cần điều chỉnh chiến lược tuyển sinh';
                        } else if (currentNew > currentGraduated * 1.2 && studyingTrend === 'tăng') {
                            scenario = '🔵 Kịch bản 3: Phát triển nhanh';
                            analysis = 'SV nhập học tăng mạnh, cần tăng cường nhân sự và cơ sở vật chất';
                        } else {
                            scenario = '🔴 Kịch bản 4: Tắc nghẽn đầu ra';
                            analysis = 'SV nhập học ổn định nhưng TN giảm, cần giải pháp tháo gỡ';
                        }
                    }
                    
                    return [
                        '',
                        `📊 ${scenario}`,
                        `💡 ${analysis}`,
                        `📈 Tỷ lệ TN/Nhập học: ${((currentGraduated/currentNew)*100).toFixed(1)}%`
                    ];
                }
            }
        }
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Render UI elements
    renderStatsCards();
    renderRiskList();
    renderFacultyList();
    renderQuickStats();
    
    // Initialize charts
    new Chart(document.getElementById('gpaChart').getContext('2d'), {
        type: 'bar',
        data: gpaChartData,
        options: gpaChartOptions
    });
    
    new Chart(document.getElementById('studentFlowChart').getContext('2d'), {
        type: 'line',
        data: studentFlowChartData,
        options: studentFlowChartOptions
    });
    
    new Chart(document.getElementById('tuitionChart').getContext('2d'), {
        type: 'bar',
        data: tuitionChartData,
        options: {
            ...chartOptions,
            plugins: {
                ...chartOptions.plugins,
                tooltip: {
                    ...chartOptions.plugins.tooltip,
                    callbacks: {
                        title: function(context) {
                            return context[0].label;
                        },
                        afterBody: function(context) {
                            const dataIndex = context[0].dataIndex;
                            const month = tuitionChartData.labels[dataIndex];
                            const collected = tuitionChartData.datasets[0].data[dataIndex];
                            const target = tuitionChartData.datasets[1].data[dataIndex];
                            const rate = tuitionChartData.datasets[2].data[dataIndex];
                            
                            return [
                                '',
                                `Số tiền đã thu: ${collected} tỷ`,
                                `Tỷ lệ thu: ${rate}%`,
                                `Mục tiêu: ${target} tỷ`,
                                '',
                                `Còn thiếu: ${(target - collected)} tỷ`,
                                `Tiến độ: ${((collected/target)*100).toFixed(1)}% mục tiêu`
                            ];
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Số tiền (tỷ VNĐ)',
                        font: { weight: 'bold' }
                    },
                    grid: { color: 'rgba(0, 0, 0, 0.05)' }
                },
                y1: {
                    beginAtZero: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Tỷ lệ thu (%)',
                        font: { weight: 'bold' }
                    },
                    grid: { drawOnChartArea: false },
                    min: 80,
                    max: 100
                }
            }
        }
    });
});
